export default function() {
	console.log("log", "a", "b");
	console.debug("debug", "a", "b");
	console.info("info", "a", "b");
	console.warn("warn", "a", "b");
	console.error("error", "a", "b");
}
