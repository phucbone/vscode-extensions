export function f1() {
  throw "line 2";
}

export function f2() {
  throw "line 6";
}

export function f3() {
  throw "line 10";
}
