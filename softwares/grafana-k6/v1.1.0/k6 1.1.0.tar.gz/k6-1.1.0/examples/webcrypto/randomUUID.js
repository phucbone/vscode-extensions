export default function () {
  const myUUID = crypto.randomUUID();

  console.log(myUUID);
}
