// Package js is the JavaScript implementation of the lib.Runner and relative concepts for
// executing concurrent-safe JavaScript code.
package js
