package js

import (
	_ "embed"
)

// ScrollIntoView scrolls an element into view.
//
//go:embed scroll_into_view.js
var ScrollIntoView string
