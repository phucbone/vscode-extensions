// Package histogram provides histogram implementations that are used to track the distribution of metrics.
package histogram
