export const options = {
    vus: 'this is an invalid type',
}

export default function () {}
