// Package event contains the event system used to notify external components of
// various internal events during test execution.
package event
